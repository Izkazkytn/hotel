CALL simpan_f_hotel('','Ruangan Spa','yji.jpg','Berada disebelah ruang parkir');
SELECT * FROM f_hotel