DELIMITER $$

CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `ci_db_hotel`.`simpan_users`(
	id_login INT(11),
	username VARCHAR(35),
	PASSWORD VARCHAR(35),
	Nama VARCHAR(255),
	Jenis_Kelamin VARCHAR(255),
	tgllahir DATE,
	no_telp VARCHAR(255),
	LEVEL ENUM
    )
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }`batal`
    | COMMENT 'string'*/
    BEGIN
	INSERT INTO users
	VALUES (id_login,username,PASSWORD,Nama,);
    END$$

DELIMITER ;